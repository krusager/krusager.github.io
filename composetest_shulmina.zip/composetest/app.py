import time

import redis
from flask import Flask

app = Flask(__name__)
cache = redis.Redis(host='redis', port=6379)


def get_hit_count():
    retries = 5
    while True:
        try:
            return cache.incr('hit')
        except redis.exceptions.ConnectionError as exc:
            if retries == 0:
                raise exc
            retries -= 1
            time.sleep(0.5)

def get_dec_count():
    return cache.decr('hit')

def reset_count():
    return cache.set('hit',0)

@app.route('/')
def hello():
    return 'Hello from Lira! What is up?\n I have been seen {} times.\n'.format(get_hit_count())

@app.route('/dec')
def decount():
    return 'On this page we has decremented count like {}'.format(get_dec_count())

@app.route('/res')
def rescount():
    reset_count()
    return 'Count was reset successfully!'
